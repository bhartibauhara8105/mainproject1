package com.niit.jobmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobmanagementApplication.class, args);
	}

}
